﻿using Game.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Hello");

            var gameEngine = GameEngine.GetInstance();

            gameEngine.Init();
            gameEngine.Start();


            Console.ReadKey();
        }
    }
}
