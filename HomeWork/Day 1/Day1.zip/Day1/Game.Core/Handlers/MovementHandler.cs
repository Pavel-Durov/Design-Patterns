﻿using HomeWork.Characters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Handlers
{
    class MovementHandler
    {
        public MovementHandler(IEnumerable<GameCharacter> characters)
        {
            _characters = characters;
        }

        IEnumerable<GameCharacter> _characters;


        public async Task Advance()
        {
            foreach (var character in _characters)
            {
                character.X += character.Step;
                character.Y += character.Step;

                await Task.Delay(300);
                Console.WriteLine(character.Location());
            }
        }
    }
}
