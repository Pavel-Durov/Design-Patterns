﻿using Game.Core.Factories;
using Game.Core.Factories.Base;
using HomeWork.Characters;
using HomeWork.Characters.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Handlers
{
    class EnemiesGenerationHandler
    {
        
        public EnemiesGenerationHandler(List<GameCharacter> characters)
        {
            _characters = characters;
            _rnd = new Random();
            InitFactories();
        }

        AbstractFactory _caveMonstersFactory;
        AbstractFactory _ghostsFactory;
        AbstractFactory _playersFactory;

        private void InitFactories()
        {
            _caveMonstersFactory = new CaveMonstersFactory();
            _ghostsFactory = new GhostsFactory();
            _playersFactory = new PlayersFactory();
        }


        Random _rnd;
        List<GameCharacter> _characters;

        public void GenerateEnemy()
        {
            int x = _rnd.Next(0, 100);
            int y = _rnd.Next(0, 100);

            GameCharacter enemy = null;
            if (x > 50)
            {
                enemy = _ghostsFactory.Generate(x, y);
            }
            else
            {
                enemy = _caveMonstersFactory.Generate(x, y);
            }
            if (enemy != null)
            {
                _characters.Add(enemy);
                Console.WriteLine($"{enemy} GENERATED at ({enemy.X}, {enemy.Y})");
            }
        }

        internal GameCharacter GeneratePlayer()
        {
            return new PlayerCharacter(0, 0);
        }
    }

}
