﻿

using Game.Core.Model;
using System;

namespace HomeWork.Characters.Enemies
{
    class GhostCharacter : GameCharacter
    {
        public GhostCharacter(Soul soul, double startXCoordinate, double startYCoordinate, double step = 1, double damage = 2) : base(startXCoordinate, startYCoordinate, step, damage)
        {
        }

        public Soul LostSoul { get; private set; }



        public override void Death()
        {
            //TODO: Implement death logic
        }

        
        public override string ToString()
        {
            return "GHOST";
        }
    }
}
