﻿

using Game.Core.Model;

namespace HomeWork.Characters.Enemies
{
    class CaveMonsterCharacter : GameCharacter
    {
        public CaveMonsterCharacter(Cave cave, double startXCoordinate, double startYCoordinate, double step = 1, double damage = 2)
            : base(startXCoordinate, startYCoordinate, step, damage)
        {
            MonsterCave = cave;
        }

        //TODO: Make your implementation
        //Reminder: Virtual methods can be overriden in the derived class



        public override void Death()
        {
            //TODO: Implement death logic
        }
        public Cave MonsterCave { get; private set; }

        
        public override string ToString()
        {
            return "CAVE MONSTER";
        }
    }
}
