﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Model
{
    class Cave
    {
        public Cave(int x, int y, string caveName)
        {
            CaveName = caveName;
            X = x;
            Y = y;
        }
        public string CaveName { get; private set; }
        public int X { get; private set; }
        public int Y { get; private set; }
    }
}
