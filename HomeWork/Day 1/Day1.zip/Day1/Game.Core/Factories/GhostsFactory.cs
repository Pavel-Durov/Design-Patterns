﻿using Game.Core.Factories.Base;
using Game.Core.Model;
using HomeWork.Characters;
using HomeWork.Characters.Enemies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Factories
{
    class GhostsFactory : AbstractFactory
    {
        const int GHOST_LIMIT = 1;
        const int GHOST_STEP = 3;
        const int GHOST_DAMAGE = 1;



        public override GameCharacter Generate(int startX, int startY)
        {
            GameCharacter result = null;
            Soul soul = new Soul("John", "Jackson");

            if (InstanceCount < GHOST_LIMIT)
            {
                result = new GhostCharacter(soul, startX, startX, GHOST_STEP, GHOST_DAMAGE);
                InstanceCount++;
            }


            return result;
        }
    }
}
