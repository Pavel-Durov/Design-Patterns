﻿using Game.Core.Factories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HomeWork.Characters;
using Game.Core.Factories.Base;
using HomeWork.Characters.Players;

namespace Game.Core.Factories
{
    class PlayersFactory : AbstractFactory
    {
        const int PLAYER_STEP = 3;
        const int PLAYER_DAMAGE = 10;

        public override GameCharacter Generate(int startX, int startY)
        {
            return new PlayerCharacter(startX, startX, PLAYER_STEP, PLAYER_DAMAGE);
        }
    }
}
