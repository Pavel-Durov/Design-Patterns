﻿using HomeWork.Characters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Factories.Base
{
    abstract class AbstractFactory
    {
        public int InstanceCount { get; protected set; }
        public abstract GameCharacter Generate(int startX, int startY);
    }
}
