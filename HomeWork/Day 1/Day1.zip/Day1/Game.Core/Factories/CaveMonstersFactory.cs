﻿using Game.Core.Factories.Base;
using Game.Core.Model;
using HomeWork.Characters;
using HomeWork.Characters.Enemies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Core.Factories
{
    class CaveMonstersFactory : AbstractFactory
    {
        const int MONSER_LIMIT = 1;
        const int MONSER_STEP = 3;
        const int MONSER_DAMAGE = 4;

        public override GameCharacter Generate(int startX, int startY)
        {


            GameCharacter result = null;
            Cave cave = new Cave(45, 45, "Best Cave Ever");


            if (InstanceCount < MONSER_LIMIT)
            {
                result = new CaveMonsterCharacter(cave, startX, startY, MONSER_STEP, MONSER_DAMAGE);

                InstanceCount++;
            }


            return result;

        }
    }
}
