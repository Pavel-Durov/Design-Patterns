﻿using Game.Core.Factories;
using Game.Core.Factories.Base;
using Game.Core.Handlers;
using HomeWork.Characters;
using HomeWork.Characters.Players;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Game.Core
{
    public class GameEngine
    {
        #region Singletone

        static GameEngine _instance;
        static object _lock = new object();

        private GameEngine()
        {
            /*DO NOTHING */
            _lock = new object();
        }

        public static GameEngine GetInstance()
        {
            lock (_lock)
            {
                if (_instance == null)
                {
                    _instance = new GameEngine();
                }
            }
            return _instance;
        }

        #endregion



        public const int ENEMY_GENERATION_DELAY = 5000;



        Task _gameTask;
        CancellationTokenSource _cancellationTokenSource;
        GameCharacter _player;
        List<GameCharacter> _characters;
        Random _rnd;

        MovementHandler _moover;
        EnemiesGenerationHandler _generator;

        public void Init()
        {
            _characters = new List<GameCharacter>();


            _moover = new MovementHandler(_characters);
            _generator = new EnemiesGenerationHandler(_characters);
            _player = _generator.GeneratePlayer();

            _rnd = new Random();

            InitGameTask();
        }

        private void InitGameTask()
        {
            _cancellationTokenSource = new CancellationTokenSource();
            _gameTask = new Task(async () =>
            {
                while (true)
                {
                    _generator.GenerateEnemy();
                    await _moover.Advance();
                    await Task.Delay(ENEMY_GENERATION_DELAY);
                }
                //Passing cancelation tken to the Task
            }, _cancellationTokenSource.Token);
        }


        public void Start()
        {
            _gameTask.Start();
        }

        public void Stop()
        {
            //calles cancel on cancelation token
            _cancellationTokenSource.Cancel();
        }
    }
}
